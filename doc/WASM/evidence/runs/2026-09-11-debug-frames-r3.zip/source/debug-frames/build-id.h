#ifndef BUILD_ID_WORDS
#error A build-bound identifier is required
#endif
