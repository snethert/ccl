(module
  (import "env" "memory" (memory 8 16 shared))
  (func (export "entry") (param $root i32) (result i32)
    (i32.add (i32.load offset=3 (local.get $root)) (i32.const 68))))