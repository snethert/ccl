int target(int x) { return x; }
