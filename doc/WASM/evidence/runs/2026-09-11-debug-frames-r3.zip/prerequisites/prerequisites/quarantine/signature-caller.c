extern int target(int, int); int use_target(void) { return target(1, 2); }
